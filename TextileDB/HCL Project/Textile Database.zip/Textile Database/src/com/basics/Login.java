package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet(urlPatterns={"/Login"})
public class Login extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
try {
	PrintWriter out=response.getWriter();
	response.setContentType("text/html");
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kabi");
String u=request.getParameter("username");
String p=request.getParameter("password");
PreparedStatement ps=con.prepareStatement("select username from login where username=? and password=?");
ps.setString(1, u);
ps.setString(2, p);
ResultSet rs=ps.executeQuery();
if(rs.next()) {
RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
rd.forward(request, response);
}else {
	out.print("<a href='Index.jsp'>Try again</a>");
}

}catch(ClassNotFoundException e) {
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
}