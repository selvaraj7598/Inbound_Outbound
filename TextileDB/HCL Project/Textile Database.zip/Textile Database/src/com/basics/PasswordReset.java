package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PasswordReset
 */
@WebServlet("/PasswordReset")
public class PasswordReset extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	public void init() {
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	 try {
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kabi");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(con);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("code"));
		String password=request.getParameter("password");
		try {
			int i;
			Statement statement=con.createStatement();
			i = statement.executeUpdate("update login set password='"+password+"'where code='"+id+"'");
			if(i>0) {
				out.print("<h1>data succeessfully updated</h1>"+i);
			}else {
				out.print("<h1>data not updated </h1>"+i);
			}
			out.print("<a href='Index.jsp'>Back to Menu</a>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    public void destroy() {
		try {
		con.close();
	}catch(SQLException e) {
		e.printStackTrace();
	}		
}
}
